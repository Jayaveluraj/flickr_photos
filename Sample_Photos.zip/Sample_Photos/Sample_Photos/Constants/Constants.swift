//
//  Constants.swift
//  Sample_Photos
//
//  Created by dev on 06/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import Foundation

struct Constants {
    static let login = "Login"
    static let logout = "Logout"
    static let home = "Home"
    static let flickrlogin = "Flikr Login"
    static let defaultMessage = "Login to View Your Photos"
    static let callBackNotificationId = "UserAuthCallbackNotification"
}
