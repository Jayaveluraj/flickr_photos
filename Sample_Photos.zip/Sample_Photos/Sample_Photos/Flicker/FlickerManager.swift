//
//  FlickerManager.swift
//  Sample_Photos
//
//  Created by dev on 06/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import Foundation
import FlickrKit

struct FlickerManager {
   static let apiKey: String = "facfdb4951ae2c7222db687d7b471365"
   static let secret: String = "79df0fbc17d0b6aa"
    static func initFlicker() {
            FlickrKit.shared().initialize(withAPIKey: apiKey, sharedSecret: secret)
    }
}
