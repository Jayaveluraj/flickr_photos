//
//  HomeViewController.swift
//  Sample_Photos
//
//  Created by dev on 06/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import UIKit
import FlickrKit

let cellIdentifier = "flickerCellIdentifier"
let authorizeSegueId = "segueAuthentication"
let publicPhotoSegueId = "publicPhotosIdentifier"
class HomeViewController: UIViewController {
    @IBOutlet weak var flikrList: UITableView!
    @IBOutlet weak var lblError: UILabel!
    var userID: String?
    var completeAuthOp: FKDUNetworkOperation!
    var checkAuthOp: FKDUNetworkOperation!
    var arrFlickerOptions = ["Public Photos", "Search Photos", "Show My Photos", "Today's Interesings"]
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        checkAuthentication()
    }

    func checkAuthentication() {
        if NetWorkAdapter.isInternetAvailable() {
            self.setObserver()
            self.checkAuthOp = FlickrKit.shared().checkAuthorization { (userName, userId, fullName, error) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    if ((error == nil)) {
                        self.userLoggedIn(userName: userName!, userID: userId!, fullName: fullName!)
                        self.reloadFlickerList()
                    } else {
                        self.userLoggedOut()
                        self.setErrorViewWith(message: (error?.localizedDescription)!)
                    }
                });
            }
        }
    }
    func userLoggedIn(userName: String, userID: String, fullName: String) {
        self.userID = userID
        self.navigationItem.rightBarButtonItem?.title = Constants.logout
        self.navigationItem.title = fullName
    }
    func registerCell() {
        self.flikrList.register(UITableViewCell.self, forCellReuseIdentifier: cellIdentifier)
        self.flikrList.tableFooterView = UIView()
    }
    
    func userLoggedOut() {
        self.userID = ""
        self.navigationItem.rightBarButtonItem?.title = Constants.login
        self.navigationItem.title = Constants.home
        self.setErrorViewWith(message: Constants.defaultMessage)
    }
    
    func reloadFlickerList() {
        if self.arrFlickerOptions.count > 0 {
            self.lblError.isHidden = true
            self.flikrList.isHidden = false
            self.flikrList.reloadData()
        }
    }
    func setErrorViewWith(message: String) {
        self.lblError.isHidden = false
        self.flikrList.isHidden = true
        self.lblError.text = message
    }
    func setObserver() {
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: Constants.callBackNotificationId), object: nil, queue: OperationQueue.main) { (notification) -> Void in
            let callBackURL: URL = notification.object as! URL
            self.completeAuthOp = FlickrKit.shared().completeAuth(with: callBackURL, completion: { (userName, userId, fullName, error) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    if ((error == nil)) {
                        self.userLoggedIn(userName: userName!, userID: userId!, fullName: fullName!)
                        self.reloadFlickerList()
                    } else {
                        if let error = error {
                            self.userLoggedOut()
                            self.setErrorViewWith(message: error.localizedDescription)
                        }
                    }
                     self.navigationController?.popToRootViewController(animated: true)
                });
            })
        }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnloginAction(_ sender: Any) {
        if FlickrKit.shared().isAuthorized {
            FlickrKit.shared().logout()
            userLoggedOut()
        }
        else
        {
            self.performSegue(withIdentifier: authorizeSegueId, sender: self)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == publicPhotoSegueId {
            let publicPhotosVc: StaggeredCollectionViewController = segue.destination as! StaggeredCollectionViewController
            publicPhotosVc.userId = self.userID
        }

    }
}
// Mark : TABLE VIEW DELEGATE AND DATASOURCE
extension HomeViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrFlickerOptions.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as UITableViewCell?)!
        cell.textLabel?.text = self.arrFlickerOptions[indexPath.row]
        cell.textLabel?.alpha = (indexPath.row == 0) ? 1.0 : 0.2
        cell.selectionStyle = .none
        cell.accessoryType = (indexPath.row == 0) ? .disclosureIndicator : .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (FlickrKit.shared().isAuthorized  && (indexPath.row == 0)) {
            self.performSegue(withIdentifier: publicPhotoSegueId, sender: self)
        }
    }

}
