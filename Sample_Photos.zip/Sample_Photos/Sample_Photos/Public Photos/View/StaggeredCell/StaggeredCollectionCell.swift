//
//  StaggeredCollectionCell.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import UIKit

class StaggeredCollectionCell: UICollectionViewCell {
    @IBOutlet weak var imagePhoto: UIImageView!
    @IBOutlet weak var lblPhotoDesc: UILabel!
    var viewModel: StaggeredCellModel?
}
extension StaggeredCollectionCell: StaggerdCollectionCellProtocol {
    func loadImageWith(imageURL: URL) {
        imagePhoto.sd_setImage(with: imageURL)
    }
    
    func setTitleWith(strTitle: String) {
        self.lblPhotoDesc.text = strTitle
    }
    
    
}
