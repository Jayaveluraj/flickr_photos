//
//  StaggeredCollectionViewController.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import UIKit
let  staggerCellIdentifier = "staggerCustomCellIdentifier"
let  nibCollectionCell = "StaggedCollectionCell"
class StaggeredCollectionViewController: UICollectionViewController {
    var userId: String?
    @IBOutlet var collectionStagger: UICollectionView!
    var viewModel : StaggeredViewModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionStagger?.contentInset = UIEdgeInsets(top: 23, left: 10, bottom: 10, right: 10)
        if let layout = collectionView?.collectionViewLayout as? CustomCollectionLayouot {
            layout.delegate = self
        }
        registerCell()
        setUpViewModel()
        fetchflickerPhotos()
    }
    // MARK : Setup ViewModel
    func setUpViewModel() {
        self.viewModel = StaggeredViewModel(view: self )
    }
    //Mark : Fetchpublic Photos
    func fetchflickerPhotos() {
        let flickerPuclicPhotos = FKFlickrPeopleGetPublicPhotos()
        flickerPuclicPhotos.extras = "url_o"
        flickerPuclicPhotos.user_id = self.userId!
        FlickrKit.shared().call(flickerPuclicPhotos) { (response, error) -> Void in
            if (error != nil) {
                print("Error fetching photos: \(String(describing: error))")
                return
            }
            if let resultsDictionary = response  as [ String : AnyObject]? {
                guard let photosContainer = resultsDictionary["photos"] as? NSDictionary,
                let photosArray = photosContainer["photo"] as? [Dictionary<String, Any>],
                    photosArray.count > 0 else {
                        return
                    }
                self.viewModel?.makePhotosWith(arrlist: photosArray)
                DispatchQueue.main.async {
                self.collectionStagger.reloadData()
                }
            }
        }
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        if let viewModel = self.viewModel {
            return viewModel.numberOfSection()
        }
        return 0
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let viewModel = self.viewModel {
            return viewModel.numberOfItemInSection()
        }
        return 0
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: staggerCellIdentifier, for: indexPath)
        guard let _ = viewModel, let staggeredCell = cell as? StaggeredCollectionCell, let photoCellModel = viewModel?.cellViewModel(indexPath: indexPath) else {
            return cell
        }
        staggeredCell.viewModel = photoCellModel
        photoCellModel.setView(cellView: staggeredCell)
        photoCellModel.setUp()
        return staggeredCell
    }
    func registerCell() {
        self.collectionStagger.register((UINib(nibName: nibCollectionCell, bundle: nil)), forCellWithReuseIdentifier: staggerCellIdentifier)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

//MARK: - PINTEREST LAYOUT DELEGATE
extension StaggeredCollectionViewController: CustomLayoutDelegate {
    func collectionView(_ collectionView: UICollectionView, heightForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        return (self.viewModel?.getHeightForImageAt(indexPath: indexPath))!
    }
    
}


extension StaggeredCollectionViewController : StaggeredCollectionViewProtocol {
    
}
