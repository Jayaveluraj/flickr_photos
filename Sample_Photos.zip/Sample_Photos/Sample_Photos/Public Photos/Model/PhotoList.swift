//
//  PhotoList.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import Foundation
class PhotoList : NSObject {
    var photoList : [Photo]?
    override init() {
        if photoList == nil {
            self.photoList  = [Photo]()
        }
        super.init()
    }
}
