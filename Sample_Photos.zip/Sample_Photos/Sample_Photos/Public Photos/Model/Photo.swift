//
//  Photo.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import Foundation
class Photo : NSObject {
    let photoId: String
    let farm: Int
    let secret: String
    let server: String
    let title: String
    let height: String
    let width: String
     init(photoDictionary: Dictionary<String, Any>) {
        let photoId = photoDictionary["id"] as? String ?? ""
        let farm = photoDictionary["farm"] as? Int ?? 0
        let secret = photoDictionary["secret"] as? String ?? ""
        let server = photoDictionary["server"] as? String ?? ""
        let title = photoDictionary["title"] as? String ?? ""
        let height = photoDictionary["height_o"] as? String ?? ""
        let width = photoDictionary["width_o"] as? String ?? ""
        self.photoId = photoId
        self.farm = farm
        self.secret = secret
        self.server = server
        self.title = title
        self.height = height
        self.width = width
        super.init()
    }
    var photoUrl: NSURL {
        return NSURL(string: "https://farm\(farm).staticflickr.com/\(server)/\(photoId)_\(secret)_m.jpg")!
    }
    
}
