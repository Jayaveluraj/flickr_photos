//
//  StaggeredViewModel.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import UIKit

class StaggeredViewModel: NSObject {
    var view: StaggeredCollectionViewProtocol?
    var photoList: PhotoList?
     init( view : StaggeredCollectionViewProtocol) {
        self.view = view
        super.init()
        if photoList == nil {
            self.photoList = PhotoList()
        }
    }
    func makePhotosWith(arrlist: [Dictionary<String, Any>]) {
        
        for photoDictionary in arrlist {
            let photo = Photo(photoDictionary: photoDictionary)
            self.photoList?.photoList?.append(photo)
        }
    }
    
    func numberOfSection() -> Int {
        return 1
    }
    func numberOfItemInSection() -> Int {
        guard  let photoList = photoList, let list = photoList.photoList else {
            return 0
        }
        return list.count
    }
    func cellViewModel(indexPath: IndexPath) -> StaggeredCellModel? {
        guard let photos = photoList,
            let photoList = photos.photoList else {
                return nil
        }
            return StaggeredCellModel(model:photoList[indexPath.row])
    }
    
    func getHeightForImageAt(indexPath: IndexPath) -> CGFloat{
        guard let photos = photoList,
            let photoList = photos.photoList else {
                return 0
        }
        guard let height = NumberFormatter().number(from: photoList[indexPath.item].height) else { return 0 }
        return CGFloat(truncating: height) + 30.0
    }
    func getLastIndexOfArray() -> Int {
        guard let photos = photoList,
            let photoList = photos.photoList else {
                return 0
        }
        return photoList.count - 1
    }

}
