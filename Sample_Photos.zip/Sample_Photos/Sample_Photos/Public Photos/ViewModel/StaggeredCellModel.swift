//
//  StaggeredCellModel.swift
//  Sample_Photos
//
//  Created by dev on 04/09/2018.
//  Copyright © 2018 jayavelu. All rights reserved.
//

import UIKit

class StaggeredCellModel: NSObject {
    var photo: Photo?
    var staggerCell : StaggerdCollectionCellProtocol?
    init(model: Photo) {
        super.init()
        if photo == nil {
            self.photo = model
        }
    }
    func setView(cellView: StaggerdCollectionCellProtocol) {
        self.staggerCell = cellView
    }
    func setUp() {
        if (self.photo?.photoUrl) != nil  {
            self.staggerCell?.loadImageWith(imageURL: (photo?.photoUrl as URL?)!)
        }
        if let title = self.photo?.title {
            self.staggerCell?.setTitleWith(strTitle: title)
        }

    }

}
